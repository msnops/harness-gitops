# ─────────────────────────────────────────────────────────────────────────────
# Root configuration — one module call per EKS cluster
#
# In TFE (Terraform Enterprise) you have two options:
#
# Option A: One TFE workspace per cluster
#   └─ Each workspace calls the module once, variables from TFE workspace vars
#
# Option B: One TFE workspace for ALL clusters (shown below)
#   └─ All module calls live here, driven by a clusters locals map
#
# Option A is recommended for blast-radius isolation.
# Option B is shown here for clarity of the pattern.
# ─────────────────────────────────────────────────────────────────────────────

locals {
  clusters = {
    "eks-prod-us-east-1" = {
      environment = "prod"
      region      = "us-east-1"
    }
    "eks-uat-us-east-1" = {
      environment = "uat"
      region      = "us-east-1"
    }
    "eks-sit-us-east-1" = {
      environment = "sit"
      region      = "us-east-1"
    }
    # Add new clusters here — one line each
    # "eks-prod-eu-west-1" = { environment = "prod", region = "eu-west-1" }
    # "eks-uat-eu-west-1"  = { environment = "uat",  region = "eu-west-1" }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# Data sources — EKS cluster connection details
# These come from the EKS TFE workspace via remote state or direct data sources
# ─────────────────────────────────────────────────────────────────────────────

# Example: pull EKS outputs from the cluster TFE workspace
# Repeat this data source block for each cluster, or use a for_each pattern

data "aws_eks_cluster" "clusters" {
  for_each = local.clusters
  name     = each.key
}

data "aws_eks_cluster_auth" "clusters" {
  for_each = local.clusters
  name     = each.key
}

# ─────────────────────────────────────────────────────────────────────────────
# Harness GitOps bootstrap — one module call per cluster
# ─────────────────────────────────────────────────────────────────────────────

module "gitops_cluster" {
  for_each = local.clusters
  source   = "./modules/harness-gitops-cluster"

  # Harness platform
  harness_org_id     = var.harness_org_id
  harness_project_id = var.harness_project_id

  # Cluster identity
  cluster_name = each.key
  environment  = each.value.environment
  region       = each.value.region

  # EKS connection (from data sources above)
  cluster_endpoint       = data.aws_eks_cluster.clusters[each.key].endpoint
  cluster_ca_certificate = data.aws_eks_cluster.clusters[each.key].certificate_authority[0].data
  cluster_token          = data.aws_eks_cluster_auth.clusters[each.key].token

  # Git repo
  git_repo_url      = var.git_repo_url
  git_repo_username = var.git_repo_username
  git_pat           = var.git_pat # from TFE sensitive variable

  # App of Apps path — matches the file created in your eks-bootstrap repo
  app_of_apps_path = "gitops/app-of-apps/${each.key}.yaml"

  # HA only for prod
  agent_high_availability = each.value.environment == "prod"

  tags = {
    team    = "platform"
    project = "eks-bootstrap"
  }
}
