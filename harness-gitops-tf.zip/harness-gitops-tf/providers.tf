terraform {
  required_version = ">= 1.5.0"

  required_providers {
    harness = {
      source  = "harness/harness"
      version = "~> 0.31"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.12"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.25"
    }
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.10"
    }
  }

  # TFE remote backend — adjust workspace names to your setup
  backend "remote" {
    organization = "your-tfe-org"
    workspaces {
      name = "harness-gitops-bootstrap"
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# Harness provider
# Credentials passed via TFE workspace sensitive variables:
#   HARNESS_ACCOUNT_ID  / TF_VAR_harness_account_id
#   HARNESS_PLATFORM_API_KEY  / TF_VAR_harness_api_key
# ─────────────────────────────────────────────────────────────────────────────

provider "harness" {
  endpoint        = "https://app.harness.io/gateway"
  account_id      = var.harness_account_id
  platform_api_key = var.harness_api_key
}

# ─────────────────────────────────────────────────────────────────────────────
# AWS provider — used to read EKS cluster data sources
# ─────────────────────────────────────────────────────────────────────────────

provider "aws" {
  region = "us-east-1" # Primary region; override per-cluster below if needed
}

# ─────────────────────────────────────────────────────────────────────────────
# Helm + Kubernetes providers
#
# NOTE: Because we're using for_each in the module and the provider must be
# configured per-cluster, there are two clean patterns:
#
# Pattern A (shown here): Single provider aliased per cluster.
#   Works well when you have a fixed, known set of clusters.
#   Add a provider alias + module provider mapping for each new cluster.
#
# Pattern B: One TFE workspace per cluster.
#   Each workspace has a single helm/kubernetes provider — simpler.
#   Recommended for large fleet (5+ clusters).
# ─────────────────────────────────────────────────────────────────────────────

# us-east-1 clusters share these providers (same region/VPC access)
provider "helm" {
  alias = "us_east_1"
  kubernetes {
    host                   = data.aws_eks_cluster.clusters["eks-prod-us-east-1"].endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.clusters["eks-prod-us-east-1"].certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.clusters["eks-prod-us-east-1"].token
  }
}

# Each cluster needs its own helm provider alias if in the same workspace.
# For brevity, only prod is shown — replicate for uat, sit, eu-west-1, etc.

# See /examples/eks-prod-us-east-1/ for the single-cluster-per-workspace pattern
# which avoids the multi-provider complexity entirely.
