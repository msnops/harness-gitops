# ─────────────────────────────────────────────────────────────────────────────
# RECOMMENDED PATTERN FOR TFE: One workspace per cluster
#
# This is simpler than the multi-cluster root module.
# Each cluster gets its own TFE workspace:
#   harness-gitops-eks-prod-us-east-1
#   harness-gitops-eks-uat-us-east-1
#   harness-gitops-eks-sit-us-east-1
#   harness-gitops-eks-prod-eu-west-1
#   ...
#
# TFE workspace variables (set per workspace):
#   cluster_name  = "eks-prod-us-east-1"
#   environment   = "prod"
#   region        = "us-east-1"
#   (sensitive) harness_account_id
#   (sensitive) harness_api_key
#   (sensitive) git_pat
# ─────────────────────────────────────────────────────────────────────────────

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    harness    = { source = "harness/harness",    version = "~> 0.31" }
    helm       = { source = "hashicorp/helm",      version = "~> 2.12" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.25" }
    aws        = { source = "hashicorp/aws",        version = "~> 5.0"  }
    time       = { source = "hashicorp/time",       version = "~> 0.10" }
  }

  backend "remote" {
    organization = "your-tfe-org"
    workspaces {
      # TFE will use the workspace name from the TFE UI / VCS trigger
      prefix = "harness-gitops-"
    }
  }
}

# ─── Providers ───────────────────────────────────────────────────────────────

provider "harness" {
  endpoint         = "https://app.harness.io/gateway"
  account_id       = var.harness_account_id
  platform_api_key = var.harness_api_key
}

provider "aws" {
  region = var.region
}

# Single cluster — no provider aliasing needed
data "aws_eks_cluster" "this" {
  name = var.cluster_name
}

data "aws_eks_cluster_auth" "this" {
  name = var.cluster_name
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.this.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.this.token
  }
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.this.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.this.token
}

provider "time" {}

# ─── Variables (set as TFE workspace variables) ───────────────────────────────

variable "harness_account_id" { type = string; sensitive = true }
variable "harness_api_key"    { type = string; sensitive = true }
variable "harness_org_id"     { type = string }
variable "harness_project_id" { type = string }
variable "cluster_name"       { type = string }  # e.g. "eks-prod-us-east-1"
variable "environment"        { type = string }  # prod | uat | sit
variable "region"             { type = string }  # e.g. "us-east-1"
variable "git_repo_url"       { type = string }
variable "git_repo_username"  { type = string }
variable "git_pat"            { type = string; sensitive = true }

# ─── Module call ─────────────────────────────────────────────────────────────

module "gitops" {
  source = "../../modules/harness-gitops-cluster"

  harness_org_id     = var.harness_org_id
  harness_project_id = var.harness_project_id

  cluster_name = var.cluster_name
  environment  = var.environment
  region       = var.region

  cluster_endpoint       = data.aws_eks_cluster.this.endpoint
  cluster_ca_certificate = data.aws_eks_cluster.this.certificate_authority[0].data
  cluster_token          = data.aws_eks_cluster_auth.this.token

  git_repo_url      = var.git_repo_url
  git_repo_username = var.git_repo_username
  git_pat           = var.git_pat

  app_of_apps_path = "gitops/app-of-apps/${var.cluster_name}.yaml"

  agent_high_availability = var.environment == "prod"
}

# ─── Outputs ─────────────────────────────────────────────────────────────────

output "agent_identifier"    { value = module.gitops.agent_identifier }
output "cluster_identifier"  { value = module.gitops.cluster_identifier }
output "app_of_apps_name"    { value = module.gitops.app_of_apps_name }
