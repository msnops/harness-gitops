# harness-gitops-cluster Terraform Module

Creates all Harness GitOps resources for one EKS cluster in code:
- GitOps Agent (registered in Harness, installed via Helm on the cluster)
- GitOps Cluster entity
- GitOps Repository (your eks-bootstrap Git repo)
- GitOps Repository Credentials
- App of Apps Application (kicks off ArgoCD self-management)

## Usage

```hcl
module "gitops_prod_us_east_1" {
  source = "./modules/harness-gitops-cluster"

  # Harness identifiers
  harness_org_id     = "my-org"
  harness_project_id = "platform"

  # Cluster identity
  cluster_name  = "eks-prod-us-east-1"
  environment   = "prod"
  region        = "us-east-1"

  # EKS cluster connection
  cluster_endpoint          = module.eks.cluster_endpoint
  cluster_ca_certificate    = module.eks.cluster_certificate_authority_data

  # Git repo
  git_repo_url      = "https://github.com/your-org/eks-bootstrap.git"
  git_repo_username = "your-org-bot"
  git_pat_secret_id = "projects/my-org/secrets/github-pat/versions/latest" # or SSM path

  # App of Apps path in the repo
  app_of_apps_path = "gitops/app-of-apps/eks-prod-us-east-1.yaml"
}
```

## One module call per cluster

```
module "gitops_prod_us_east_1"   → eks-prod-us-east-1
module "gitops_uat_us_east_1"    → eks-uat-us-east-1
module "gitops_sit_us_east_1"    → eks-sit-us-east-1
module "gitops_prod_eu_west_1"   → eks-prod-eu-west-1
...
```

## What this does NOT manage

- EKS cluster itself (managed by separate TFE workspace)
- IRSA roles (managed by EKS TFE workspace, outputs fed into environments/ values files)
- The helm charts and ArgoCD Applications in gitops/ (managed by ArgoCD itself after bootstrap)
