locals {
  # Harness-safe identifier: lowercase, hyphens only, no dots
  # e.g. "eks-prod-us-east-1"
  identifier = var.cluster_name

  # Human-readable name shown in Harness UI
  display_name = "${var.cluster_name} (${var.environment} / ${var.region})"

  # Merged tags applied to all Harness resources
  common_tags = merge(
    {
      environment = var.environment
      region      = var.region
      cluster     = var.cluster_name
      managed-by  = "terraform"
    },
    var.tags
  )

  # HA is always on for prod, optional for others
  high_availability = var.environment == "prod" ? true : var.agent_high_availability
}
