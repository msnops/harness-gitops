# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Register the GitOps Agent in Harness
#
# This creates the agent entity in the Harness control plane.
# It does NOT install anything on the cluster yet — that's the helm_release below.
# The agent_token output is what ties the two together.
# ─────────────────────────────────────────────────────────────────────────────

resource "harness_platform_gitops_agent" "this" {
  identifier = local.identifier
  name       = local.display_name
  org_id     = var.harness_org_id
  project_id = var.harness_project_id

  # MANAGED_ARGO_PROVIDER = Harness installs and manages ArgoCD
  # CONNECTED_ARGO_PROVIDER = bring your own existing ArgoCD instance
  type     = "MANAGED_ARGO_PROVIDER"
  operator = "ARGO"

  metadata {
    namespace        = var.agent_namespace
    high_availability = local.high_availability
  }

  tags = local.common_tags
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — Install the GitOps Agent on the EKS cluster via Helm
#
# Uses the agent_token from step 1 to authenticate the agent back to Harness.
# The helm provider is configured in the root module with the EKS cluster creds.
# ─────────────────────────────────────────────────────────────────────────────

resource "helm_release" "gitops_agent" {
  name             = "harness-gitops-agent"
  repository       = "https://harness.github.io/gitops-helm/"
  chart            = "gitops-helm"
  namespace        = var.agent_namespace
  create_namespace = true

  # Wait for all agent pods to be Running before Terraform continues
  wait    = true
  timeout = 300 # 5 minutes

  values = [
    yamlencode({
      agent = {
        accountId  = harness_platform_gitops_agent.this.account_id
        identifier = harness_platform_gitops_agent.this.identifier
        token      = harness_platform_gitops_agent.this.agent_token
        # Harness SaaS endpoint — change if using on-prem Harness
        target   = "https://app.harness.io"
        protocol = "HTTPS"
      }

      "argo-cd" = {
        crds = {
          install = true
          # CRITICAL: never delete CRDs on helm uninstall
          # Deleting CRDs destroys all ArgoCD Applications
          keep = true
        }

        global = {
          image = {
            imagePullPolicy = var.agent_image_pull_policy
          }
        }

        server = {
          autoscale = {
            enabled = false
          }
          resources = {
            requests = {
              cpu    = local.high_availability ? "200m" : "100m"
              memory = local.high_availability ? "256Mi" : "128Mi"
            }
            limits = {
              cpu    = local.high_availability ? "500m" : "300m"
              memory = local.high_availability ? "512Mi" : "256Mi"
            }
          }
        }

        controller = {
          replicas = local.high_availability ? 2 : 1
          resources = {
            requests = {
              cpu    = local.high_availability ? "500m" : "250m"
              memory = local.high_availability ? "1Gi" : "512Mi"
            }
          }
        }

        repoServer = {
          replicas = local.high_availability ? 2 : 1
          resources = {
            requests = {
              cpu    = "250m"
              memory = "256Mi"
            }
          }
        }

        applicationSet = {
          replicas = local.high_availability ? 2 : 1
        }

        redis = {
          resources = {
            requests = {
              cpu    = "100m"
              memory = "64Mi"
            }
          }
        }
      }
    })
  ]

  depends_on = [harness_platform_gitops_agent.this]
}

# Short wait after agent install — gives agent time to establish connection to Harness
# before we try to register the cluster entity against it
resource "time_sleep" "agent_ready" {
  create_duration = "30s"
  depends_on      = [helm_release.gitops_agent]
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — Register the Cluster in Harness GitOps
#
# This creates the Harness "Cluster" entity that maps to your EKS cluster.
# The agent manages the connection — no cluster credentials stored in Harness.
# ─────────────────────────────────────────────────────────────────────────────

resource "harness_platform_gitops_cluster" "this" {
  identifier = local.identifier
  org_id     = var.harness_org_id
  project_id = var.harness_project_id
  agent_id   = harness_platform_gitops_agent.this.identifier

  request {
    upsert = true

    cluster {
      name   = local.display_name
      server = var.cluster_endpoint

      # in-cluster auth — agent runs inside the cluster so no external credentials needed
      config {
        tls_client_config {
          # Empty = use in-cluster service account token (recommended)
          insecure = false
          ca_data  = var.cluster_ca_certificate
        }
      }

      # Labels used by ApplicationSet cluster generator to fan out to this cluster
      labels = {
        environment = var.environment
        region      = var.region
        cluster     = var.cluster_name
        bootstrap   = "true"
      }

      annotations = {
        "managed-by" = "terraform"
      }
    }
  }

  depends_on = [time_sleep.agent_ready]
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Register the Git Repository in Harness GitOps
#
# This tells the agent where to pull manifests from.
# ─────────────────────────────────────────────────────────────────────────────

resource "harness_platform_gitops_repository" "this" {
  identifier = replace(var.cluster_name, "-", "_") # identifiers can't have hyphens in repo resource
  org_id     = var.harness_org_id
  project_id = var.harness_project_id
  agent_id   = harness_platform_gitops_agent.this.identifier

  repo {
    repo           = var.git_repo_url
    name           = "eks-bootstrap"
    connection_type = "HTTPS"
    type_          = "git"

    username = var.git_repo_username
    password = var.git_pat # stored as Harness secret reference or passed directly
  }

  upsert           = true
  update_mask {
    paths = ["name", "repo", "username", "password"]
  }

  depends_on = [harness_platform_gitops_cluster.this]
}

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Create the App of Apps GitOps Application
#
# This is the single ArgoCD Application that, when synced, creates all child
# Applications (namespaces, ESO, ALB controller, nginx-ingress, TGB, etc.)
# ArgoCD takes over from here — Terraform's job is done after this resource.
# ─────────────────────────────────────────────────────────────────────────────

resource "harness_platform_gitops_applications" "app_of_apps" {
  identifier = "bootstrap-${local.identifier}"
  org_id     = var.harness_org_id
  project_id = var.harness_project_id
  agent_id   = harness_platform_gitops_agent.this.identifier
  cluster_id = harness_platform_gitops_cluster.this.identifier
  repo_id    = harness_platform_gitops_repository.this.identifier

  application {
    metadata {
      name      = "bootstrap-${local.identifier}"
      namespace = var.agent_namespace

      labels = {
        "harness.io/envRef"     = var.environment
        "harness.io/serviceRef" = "eks-bootstrap"
        "managed-by"            = "terraform"
      }

      annotations = {
        # Wave 0 — this must sync before all child apps
        "argocd.argoproj.io/sync-wave" = "0"
      }

      finalizers = [
        "resources-finalizer.argocd.argoproj.io"
      ]
    }

    spec {
      project = "default"

      source {
        repo_url        = var.git_repo_url
        target_revision = var.git_target_revision
        path            = dirname(var.app_of_apps_path)
      }

      destination {
        # in-cluster — agent targets its own cluster
        server    = "https://kubernetes.default.svc"
        namespace = var.agent_namespace
      }

      sync_policy {
        sync_options = [
          "CreateNamespace=true",
          "PrunePropagationPolicy=foreground",
          "PruneLast=true",
        ]

        dynamic "automated" {
          for_each = var.auto_sync_enabled ? [1] : []
          content {
            self_heal   = var.self_heal_enabled
            prune       = var.prune_enabled
            allow_empty = false
          }
        }

        retry {
          limit = "5"
          backoff {
            duration     = "5s"
            factor       = "2"
            max_duration = "3m"
          }
        }
      }
    }
  }

  depends_on = [harness_platform_gitops_repository.this]
}
