output "agent_identifier" {
  description = "Harness GitOps Agent identifier — use this to reference the agent in other resources"
  value       = harness_platform_gitops_agent.this.identifier
}

output "agent_token" {
  description = "Agent authentication token — sensitive, only used internally by the helm_release"
  value       = harness_platform_gitops_agent.this.agent_token
  sensitive   = true
}

output "cluster_identifier" {
  description = "Harness GitOps Cluster identifier"
  value       = harness_platform_gitops_cluster.this.identifier
}

output "repository_identifier" {
  description = "Harness GitOps Repository identifier"
  value       = harness_platform_gitops_repository.this.identifier
}

output "app_of_apps_name" {
  description = "Name of the App of Apps ArgoCD Application created in Harness"
  value       = harness_platform_gitops_applications.app_of_apps.identifier
}

output "agent_namespace" {
  description = "Kubernetes namespace where the GitOps agent is installed"
  value       = var.agent_namespace
}
