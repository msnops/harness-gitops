# ─────────────────────────────────────────────
# Harness Platform Identifiers
# ─────────────────────────────────────────────

variable "harness_org_id" {
  description = "Harness organisation identifier"
  type        = string
}

variable "harness_project_id" {
  description = "Harness project identifier"
  type        = string
}

# ─────────────────────────────────────────────
# Cluster Identity
# ─────────────────────────────────────────────

variable "cluster_name" {
  description = "EKS cluster name, e.g. eks-prod-us-east-1. Used as Harness identifiers."
  type        = string
}

variable "environment" {
  description = "Environment tier: prod | uat | sit"
  type        = string

  validation {
    condition     = contains(["prod", "uat", "sit"], var.environment)
    error_message = "environment must be one of: prod, uat, sit"
  }
}

variable "region" {
  description = "AWS region, e.g. us-east-1"
  type        = string
}

# ─────────────────────────────────────────────
# EKS Cluster Connection
# Typically passed from your EKS TFE workspace outputs
# ─────────────────────────────────────────────

variable "cluster_endpoint" {
  description = "EKS cluster API server endpoint URL"
  type        = string
}

variable "cluster_ca_certificate" {
  description = "Base64-encoded cluster CA certificate (from EKS module output)"
  type        = string
  sensitive   = true
}

variable "cluster_token" {
  description = "Short-lived auth token for the cluster. For TFE use a data source or pass via env."
  type        = string
  sensitive   = true
  default     = ""
}

# ─────────────────────────────────────────────
# Harness GitOps Agent
# ─────────────────────────────────────────────

variable "agent_namespace" {
  description = "Kubernetes namespace to install the Harness GitOps agent into"
  type        = string
  default     = "argocd"
}

variable "agent_high_availability" {
  description = "Enable HA mode for the GitOps agent (recommended for prod)"
  type        = bool
  default     = false
}

variable "agent_image_pull_policy" {
  description = "Image pull policy for GitOps agent containers"
  type        = string
  default     = "Always"
}

# ─────────────────────────────────────────────
# Git Repository
# ─────────────────────────────────────────────

variable "git_repo_url" {
  description = "HTTPS URL of your eks-bootstrap Git repository"
  type        = string
}

variable "git_repo_username" {
  description = "Git username for HTTPS authentication (e.g. a bot account)"
  type        = string
}

variable "git_pat" {
  description = "Personal access token or app password for Git repo authentication"
  type        = string
  sensitive   = true
}

variable "git_target_revision" {
  description = "Git branch or tag ArgoCD will sync from"
  type        = string
  default     = "main"
}

# ─────────────────────────────────────────────
# App of Apps
# ─────────────────────────────────────────────

variable "app_of_apps_path" {
  description = <<-EOT
    Path inside the git repo to the App of Apps manifest for this cluster.
    e.g. "gitops/app-of-apps/eks-prod-us-east-1.yaml"
  EOT
  type        = string
}

variable "auto_sync_enabled" {
  description = "Enable automated sync on the App of Apps application"
  type        = bool
  default     = true
}

variable "self_heal_enabled" {
  description = "Enable self-healing (revert manual cluster changes) on App of Apps"
  type        = bool
  default     = true
}

variable "prune_enabled" {
  description = "Enable pruning of resources removed from Git"
  type        = bool
  default     = true
}

# ─────────────────────────────────────────────
# Tags
# ─────────────────────────────────────────────

variable "tags" {
  description = "Additional tags to apply to all Harness resources"
  type        = map(string)
  default     = {}
}
