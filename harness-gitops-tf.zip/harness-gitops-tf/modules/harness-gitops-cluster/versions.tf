terraform {
  required_version = ">= 1.5.0"

  required_providers {
    # Harness provider — manages all Harness platform entities
    harness = {
      source  = "harness/harness"
      version = "~> 0.31"
    }

    # Helm provider — installs the GitOps agent onto the EKS cluster
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.12"
    }

    # Kubernetes provider — waits for agent pods to be ready
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.25"
    }

    # Time provider — small delay after agent registration before cluster entity
    time = {
      source  = "hashicorp/time"
      version = "~> 0.10"
    }
  }
}
