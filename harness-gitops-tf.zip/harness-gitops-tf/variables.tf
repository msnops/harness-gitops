# ─────────────────────────────────────────────
# Harness credentials — set as TFE sensitive workspace variables
# ─────────────────────────────────────────────

variable "harness_account_id" {
  description = "Harness account ID (found in URL after /account/)"
  type        = string
  sensitive   = true
}

variable "harness_api_key" {
  description = "Harness platform API key (PAT or SA token)"
  type        = string
  sensitive   = true
}

variable "harness_org_id" {
  description = "Harness organisation identifier"
  type        = string
}

variable "harness_project_id" {
  description = "Harness project identifier"
  type        = string
}

# ─────────────────────────────────────────────
# Git repo
# ─────────────────────────────────────────────

variable "git_repo_url" {
  description = "HTTPS URL of your eks-bootstrap GitOps repository"
  type        = string
  default     = "https://github.com/your-org/eks-bootstrap.git"
}

variable "git_repo_username" {
  description = "Git username for repo authentication"
  type        = string
}

variable "git_pat" {
  description = "Git personal access token — set as TFE sensitive variable"
  type        = string
  sensitive   = true
}
